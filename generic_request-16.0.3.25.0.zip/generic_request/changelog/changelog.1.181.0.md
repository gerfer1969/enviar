***BUG220930***
Fixed bug, when contact related request count shown wrong after merging them

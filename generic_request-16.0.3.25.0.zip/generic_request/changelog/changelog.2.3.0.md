***BUG220963***
Fix bug when request assigned on inactive channels

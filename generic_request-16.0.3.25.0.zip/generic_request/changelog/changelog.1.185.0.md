Added new *Internal Notes* page on request form.
There team can add some internal notes related to request,
that will not be displayed on website for customer and
that will not be forgotten in chat history.

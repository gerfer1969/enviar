Added *searchpanel* to requests, thus now it is possible to easily filter requests by category, type, service, tags and stage type.

***BUG220980***
- Fixed incorrect behavior of filters related to time

Added ability to show/hide columns in tree view

Enable *create_edit* and *quick_create* features of *author* and *partner*
fields of request 

Fix regression in detection of author when creator is specified directly,
but author is not specified.

Added tracking visibility when changing `deadline` field

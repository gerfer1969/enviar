Show open/closed requests stat for request's partner and author

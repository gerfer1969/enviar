New request event categories:
- *Deadline Tomorrow*
- *Deadline Today*
- *Deadline Overdue*

Fixed count of opened/closed author related requests on request form.
Now displays the valid number of author requests regardless of user rights.
Implemented within request BUG231020.

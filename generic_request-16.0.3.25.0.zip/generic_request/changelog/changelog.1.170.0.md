Improved appearance of request tags on kanban view

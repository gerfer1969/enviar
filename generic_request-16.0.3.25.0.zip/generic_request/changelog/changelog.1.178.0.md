Refactored settings UI: moved mail-related settings to separate section

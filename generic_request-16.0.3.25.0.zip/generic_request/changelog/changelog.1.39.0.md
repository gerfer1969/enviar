- Fixed bug when with incorrect display of images in request text,
  when request was created by email.
- Added `lessc` to external dependencies, to avoid confusion for users that
  have not installed `lessc` compiler. It become optional for 12.0+ installations.

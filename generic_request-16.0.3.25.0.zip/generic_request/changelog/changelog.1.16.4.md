#### Version 1.16.4
Add security groups user_see_all_requests and user_write_all_requests and rules for this groups

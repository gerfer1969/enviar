Changed access restrictions.
Now in order to have access to Assign/Reassign and Change Parent Request the user must belong to `Request User` group.

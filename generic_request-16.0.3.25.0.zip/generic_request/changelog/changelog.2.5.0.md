Fixed bug with incorrect handling of record-created event actions.

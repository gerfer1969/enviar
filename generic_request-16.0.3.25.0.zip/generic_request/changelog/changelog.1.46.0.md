Module `generic_request_tag` merged into `generic_request`

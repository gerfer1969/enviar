Merge the generic_request_parent as module into the generic_request module

Added settings menu for request mail templates

Added support for saving positions in diagram view

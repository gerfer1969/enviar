Add response attachment files when closing requests.

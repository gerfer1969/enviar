Fixed bug in event notifications, 
that happens when default notification settings set to False
and event messages of subrequest didn't  deliver to parent request.

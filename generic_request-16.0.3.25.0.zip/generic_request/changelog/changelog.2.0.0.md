Start using Generic System Events under the hood.

**Do not forget to take backup before updating.**

Use different colors for deadline icon, depending on its value.

Added new context manager `generic_mixin.tests.common.FindNew`
that could be used to easily find new records
created during execution of with block.

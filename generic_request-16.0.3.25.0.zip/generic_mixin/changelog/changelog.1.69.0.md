Delegation mixins now implement their own decorator `interface_proxy` that
could be used to mark methods of interface model,
that have to be proxied to implementation model.

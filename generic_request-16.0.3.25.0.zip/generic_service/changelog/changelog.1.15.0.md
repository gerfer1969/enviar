Now services inherited from *Entity Lifecycle Mixin*,
thus service have lifecycle state and dates.

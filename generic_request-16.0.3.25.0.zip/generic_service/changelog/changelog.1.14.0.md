License changed to *LGPL-3*

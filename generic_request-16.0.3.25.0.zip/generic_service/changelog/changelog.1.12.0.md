Added ability to allow access for specific groups of users for services.
Previously this functionality was available only in crnd_wsd_service module,
but now it was moved to this core module generic_service.

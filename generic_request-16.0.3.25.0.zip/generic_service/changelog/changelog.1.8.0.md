Added field `code` for Services model.

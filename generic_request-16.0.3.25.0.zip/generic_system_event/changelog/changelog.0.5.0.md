Added support of vacuuming events.
So, now it is possible to configure automatic removal of events after certain period of time.

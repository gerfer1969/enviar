Function `generic_m2o.tools.utils.generic_m2o_get` deprecated.
It was moved to `generic_mixin.tools.generic_m2o`.
